-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 11. Jul 2013 um 16:19
-- Server Version: 5.5.31
-- PHP-Version: 5.4.4-14+deb7u2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `dokuit3`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `benutzer`
--

CREATE TABLE IF NOT EXISTS `benutzer` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `benutzername` varchar(30) NOT NULL,
  `einstellung_dns` varchar(3) NOT NULL DEFAULT 'ip',
  `allekunden_sichtbar` varchar(5) NOT NULL DEFAULT 'FALSE',
  `allegeraete_sichtbar` varchar(5) NOT NULL DEFAULT 'FALSE',
  `letzter_kunde` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `benutzer_kunden_einstellung`
--

CREATE TABLE IF NOT EXISTS `benutzer_kunden_einstellung` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `benutzerid` int(11) NOT NULL,
  `kundenid` int(11) NOT NULL DEFAULT '1',
  `sichtbar` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COMMENT='Zum Speichern, ob ein Kunde bei einem bestimmten Benutzer an' AUTO_INCREMENT=87 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `bilder`
--

CREATE TABLE IF NOT EXISTS `bilder` (
  `id` bigint(21) NOT NULL AUTO_INCREMENT,
  `kunde` bigint(21) NOT NULL DEFAULT '0',
  `name` varchar(60) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `url` text COLLATE latin1_german1_ci NOT NULL,
  `bemerkung` text COLLATE latin1_german1_ci,
  `loeschen` tinyint(1) NOT NULL DEFAULT '1',
  `loeschentime` int(10) unsigned DEFAULT NULL COMMENT 'Hier kommt ein Timestamp aus PHP rein.',
  PRIMARY KEY (`id`),
  FULLTEXT KEY `name` (`name`,`bemerkung`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci AUTO_INCREMENT=34 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `dokumente`
--

CREATE TABLE IF NOT EXISTS `dokumente` (
  `id` bigint(21) NOT NULL AUTO_INCREMENT,
  `kunde` bigint(21) NOT NULL DEFAULT '0',
  `name` varchar(60) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `url` text COLLATE latin1_german1_ci NOT NULL,
  `bemerkung` text COLLATE latin1_german1_ci,
  `loeschen` tinyint(1) NOT NULL DEFAULT '1',
  `loeschentime` int(10) unsigned DEFAULT NULL COMMENT 'Hier kommt ein Timestamp aus PHP rein.',
  PRIMARY KEY (`id`),
  FULLTEXT KEY `name` (`name`,`bemerkung`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci AUTO_INCREMENT=16 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `geraete`
--

CREATE TABLE IF NOT EXISTS `geraete` (
  `id` bigint(21) NOT NULL AUTO_INCREMENT,
  `kunde` bigint(21) NOT NULL DEFAULT '0',
  `kategorie` bigint(21) NOT NULL DEFAULT '0',
  `system` varchar(30) COLLATE latin1_german1_ci DEFAULT NULL,
  `bs` varchar(50) COLLATE latin1_german1_ci DEFAULT NULL,
  `pc` varchar(30) COLLATE latin1_german1_ci DEFAULT NULL,
  `sn` varchar(30) COLLATE latin1_german1_ci DEFAULT NULL,
  `produktnummer` varchar(20) COLLATE latin1_german1_ci DEFAULT NULL,
  `garantie` varchar(40) COLLATE latin1_german1_ci DEFAULT NULL,
  `name` varchar(40) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `adresse` varchar(100) COLLATE latin1_german1_ci DEFAULT NULL,
  `ipv4` varchar(17) COLLATE latin1_german1_ci DEFAULT NULL,
  `dnstimestamp` varchar(12) COLLATE latin1_german1_ci DEFAULT NULL,
  `port` varchar(10) COLLATE latin1_german1_ci DEFAULT NULL,
  `benutzer` varchar(30) COLLATE latin1_german1_ci DEFAULT NULL,
  `zimmer` varchar(30) COLLATE latin1_german1_ci DEFAULT NULL,
  `drucker` text COLLATE latin1_german1_ci,
  `router` varchar(15) COLLATE latin1_german1_ci DEFAULT NULL,
  `irdpport` varchar(30) COLLATE latin1_german1_ci DEFAULT NULL,
  `programme` text COLLATE latin1_german1_ci,
  `vncpasswort` varchar(20) COLLATE latin1_german1_ci DEFAULT NULL,
  `login` varchar(20) COLLATE latin1_german1_ci DEFAULT NULL,
  `passwort` varchar(20) COLLATE latin1_german1_ci DEFAULT NULL,
  `ftplogin` text COLLATE latin1_german1_ci,
  `ftppasswort` varchar(200) COLLATE latin1_german1_ci DEFAULT NULL,
  `ftpdir` varchar(200) COLLATE latin1_german1_ci DEFAULT NULL,
  `ds_check` tinyint(1) NOT NULL DEFAULT '0',
  `bemerkung` text COLLATE latin1_german1_ci,
  `tv_id` varchar(30) COLLATE latin1_german1_ci DEFAULT NULL,
  `tv_pwd` varchar(30) COLLATE latin1_german1_ci NOT NULL DEFAULT '$Team7981%',
  `mac_adresse` varchar(17) COLLATE latin1_german1_ci DEFAULT NULL,
  `xurl` varchar(200) COLLATE latin1_german1_ci DEFAULT NULL,
  `loeschen` tinyint(1) NOT NULL DEFAULT '1',
  `loeschentime` int(10) unsigned DEFAULT NULL COMMENT 'Hier kommt ein Timestamp aus PHP rein.',
  PRIMARY KEY (`id`),
  FULLTEXT KEY `name` (`name`,`system`,`produktnummer`,`pc`,`benutzer`),
  FULLTEXT KEY `bemerkung` (`bemerkung`),
  FULLTEXT KEY `sn` (`sn`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci AUTO_INCREMENT=1738 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `geraete_login`
--

CREATE TABLE IF NOT EXISTS `geraete_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `geraete_id` int(11) NOT NULL,
  `programm_id` int(11) NOT NULL,
  `login` text NOT NULL,
  `passwort` varchar(40) DEFAULT NULL,
  `aktiv` tinyint(1) NOT NULL,
  `bemerkung` text,
  `loeschen` tinyint(1) NOT NULL DEFAULT '1',
  `loeschentime` int(10) unsigned DEFAULT NULL COMMENT 'Hier kommt ein Timestamp aus PHP rein.',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2896 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `kategorien`
--

CREATE TABLE IF NOT EXISTS `kategorien` (
  `id` bigint(21) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `Skript` varchar(200) COLLATE latin1_german1_ci NOT NULL DEFAULT 'fernwart.php5',
  `showsort` tinyint(4) NOT NULL DEFAULT '1',
  `fernwart` tinyint(1) NOT NULL DEFAULT '0',
  `bemerkung` text COLLATE latin1_german1_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ktg_name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci AUTO_INCREMENT=11 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `kunden`
--

CREATE TABLE IF NOT EXISTS `kunden` (
  `id` bigint(21) NOT NULL AUTO_INCREMENT,
  `kuerzel` varchar(5) COLLATE latin1_german1_ci DEFAULT NULL,
  `name` varchar(50) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `starturl` varchar(255) COLLATE latin1_german1_ci NOT NULL DEFAULT '\\\\uhdsrv01\\vol1\\Usr\\Texte\\Techdoku\\Kunden\\',
  `routerip` varchar(15) COLLATE latin1_german1_ci DEFAULT NULL,
  `bemerkung` text COLLATE latin1_german1_ci,
  `strasse` varchar(80) COLLATE latin1_german1_ci DEFAULT NULL,
  `hausnummer` varchar(80) COLLATE latin1_german1_ci DEFAULT NULL,
  `plz` varchar(80) COLLATE latin1_german1_ci DEFAULT NULL,
  `ort` varchar(80) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `telefon` varchar(80) COLLATE latin1_german1_ci DEFAULT NULL,
  `fax` varchar(80) COLLATE latin1_german1_ci DEFAULT NULL,
  `asp1_name` varchar(80) COLLATE latin1_german1_ci DEFAULT NULL,
  `asp1_telefon` varchar(80) COLLATE latin1_german1_ci DEFAULT NULL,
  `asp1_mail` varchar(80) COLLATE latin1_german1_ci DEFAULT NULL,
  `asp2_name` varchar(80) COLLATE latin1_german1_ci DEFAULT NULL,
  `asp2_telefon` varchar(80) COLLATE latin1_german1_ci DEFAULT NULL,
  `asp2_mail` varchar(80) COLLATE latin1_german1_ci DEFAULT NULL,
  `wartung` text COLLATE latin1_german1_ci,
  `dyndns_domain` varchar(200) COLLATE latin1_german1_ci DEFAULT NULL,
  `vnc_repeater` varchar(5) COLLATE latin1_german1_ci NOT NULL DEFAULT '5901',
  PRIMARY KEY (`id`),
  UNIQUE KEY `kd_name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci AUTO_INCREMENT=42 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `programme`
--

CREATE TABLE IF NOT EXISTS `programme` (
  `id` bigint(21) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `url` text COLLATE latin1_german1_ci NOT NULL,
  `port` varchar(5) COLLATE latin1_german1_ci DEFAULT NULL,
  `repeater_port` varchar(5) COLLATE latin1_german1_ci DEFAULT NULL,
  `use_internet` tinyint(1) NOT NULL DEFAULT '0',
  `bemerkung` varchar(200) COLLATE latin1_german1_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `prg_name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci AUTO_INCREMENT=27 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `routing`
--

CREATE TABLE IF NOT EXISTS `routing` (
  `id` bigint(21) NOT NULL AUTO_INCREMENT,
  `kunde` bigint(21) NOT NULL DEFAULT '0',
  `name` varchar(60) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `ziel` text COLLATE latin1_german1_ci,
  `maske` text COLLATE latin1_german1_ci,
  `gateway` text COLLATE latin1_german1_ci,
  `bemerkung` text COLLATE latin1_german1_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `zugangsdaten`
--

CREATE TABLE IF NOT EXISTS `zugangsdaten` (
  `id` bigint(21) NOT NULL AUTO_INCREMENT,
  `kunde` bigint(21) NOT NULL DEFAULT '0',
  `titel` varchar(60) COLLATE latin1_german1_ci NOT NULL DEFAULT '',
  `login` varchar(200) COLLATE latin1_german1_ci DEFAULT NULL,
  `passwort` varchar(200) COLLATE latin1_german1_ci DEFAULT NULL,
  `zusatz` text COLLATE latin1_german1_ci,
  `url` text COLLATE latin1_german1_ci,
  `bemerkung` text COLLATE latin1_german1_ci,
  `loeschen` tinyint(1) NOT NULL DEFAULT '1',
  `loeschentime` int(10) unsigned DEFAULT NULL COMMENT 'Hier kommt ein Timestamp aus PHP rein.',
  PRIMARY KEY (`id`),
  FULLTEXT KEY `titel` (`titel`,`zusatz`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_german1_ci AUTO_INCREMENT=365 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
